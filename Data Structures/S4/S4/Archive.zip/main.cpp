#include <iostream>
#include "InteractivePhoneBook.h"
#include "StringContactMap.h"

int main()
{
    InteractivePhoneBook pb;
    pb.start();
    
    return 0;
}

