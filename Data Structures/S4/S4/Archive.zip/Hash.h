#ifndef HASH_H
#define HASH_H

#include <string>

using namespace std;

unsigned int hash_func(string s);

#endif
