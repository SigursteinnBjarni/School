#include <iostream>
#include "CharStack.h"
using namespace std;

bool safe_to_publish(string book)
{
    CharStack myBook;
    char opening, closing;
    
    for (size_t i = 0; i < book.size(); i++) {
        opening = book[i];
        // if the bracet is opening we push it onto the stack
        if (opening == '(') {
            myBook.push(opening);
        }
        
        else{
            // if our stack is empty it means we have no opening bracets
            if (myBook.empty()) {
                return false;
            }
            // we take the closing bracet and we pop it out of the stack
            closing = myBook.pop();
            if (opening == '(' && closing == ')') {
                return true;
            }
        }
        
    }
    return myBook.empty();
}

int main(int argc, const char * argv[])
{
    string bracets;
    cin >> bracets;
    if (safe_to_publish(bracets))
    {
        cout << "Publish" << endl;
    }
    
    else
    {
        cout << "Fix bracets" << endl;
    }
    
    return 0;
}

