#include <iostream>
#include <vector>
#include "InteractivePhoneBook.h"
#include <cstdlib>

using namespace std;

int main()
{
    InteractivePhoneBook phonebook;
    phonebook.start();

    return 0;
}
